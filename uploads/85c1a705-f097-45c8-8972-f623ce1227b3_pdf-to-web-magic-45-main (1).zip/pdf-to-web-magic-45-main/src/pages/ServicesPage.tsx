import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { servicesData } from "@/data/servicesData";

const ServicesPage = () => (
  <div className="min-h-screen">
    <Navbar />

    {/* Hero */}
    <section className="gradient-hero pt-32 pb-20 md:pt-40 md:pb-28">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-3xl"
        >
          <span className="inline-block px-4 py-1.5 rounded-full bg-primary-foreground/15 text-primary-foreground text-sm font-medium mb-6 backdrop-blur-sm border border-primary-foreground/20">
            Our Services
          </span>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-primary-foreground leading-tight mb-4">
            Comprehensive <span className="text-accent">Assessment Solutions</span>
          </h1>
          <p className="text-lg md:text-xl text-primary-foreground/80 max-w-xl leading-relaxed">
            Tailored evaluation services for every sector of the education and employment ecosystem.
          </p>
        </motion.div>
      </div>
    </section>

    {/* Services Grid */}
    <section className="py-20 md:py-28">
      <div className="container">
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {servicesData.map((s, i) => (
            <motion.div
              key={s.slug}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, duration: 0.5 }}
            >
              <Link
                to={`/services/${s.slug}`}
                className="group block bg-card rounded-2xl p-8 shadow-card hover:shadow-card-hover transition-all duration-300 border border-border h-full"
              >
                <div className="h-14 w-14 rounded-xl gradient-hero flex items-center justify-center mb-5">
                  <s.icon className="h-7 w-7 text-primary-foreground" />
                </div>
                <h3 className="text-lg font-bold text-foreground mb-3">{s.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed mb-3">{s.subtitle}</p>
                <p className="text-muted-foreground text-sm leading-relaxed mb-5">{s.heroDesc}</p>

                <div className="mb-5">
                  <h4 className="text-xs font-semibold text-foreground uppercase tracking-wider mb-2">Key Features</h4>
                  <ul className="space-y-1">
                    {s.features.slice(0, 3).map((f) => (
                      <li key={f.title} className="text-xs text-muted-foreground flex items-center gap-2">
                        <span className="h-1.5 w-1.5 rounded-full bg-secondary shrink-0" />
                        {f.title}
                      </li>
                    ))}
                  </ul>
                </div>

                <span className="inline-flex items-center text-sm font-semibold text-primary group-hover:gap-2 transition-all">
                  View Details <ArrowRight className="ml-1 h-4 w-4" />
                </span>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>

    {/* CTA */}
    <section className="py-20 md:py-28 gradient-hero">
      <div className="container text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold text-primary-foreground mb-4">
            Not Sure Which Service Fits?
          </h2>
          <p className="text-primary-foreground/70 max-w-lg mx-auto mb-8">
            Contact our team for a free consultation and we'll recommend the best solution for your needs.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/request-demo" className="inline-flex items-center justify-center rounded-md bg-secondary text-secondary-foreground px-8 py-3 text-base font-semibold hover:bg-secondary/90 transition-colors">
              Request Demo <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
            <Link to="/contact" className="inline-flex items-center justify-center rounded-md border border-primary-foreground/30 text-primary-foreground px-8 py-3 text-base font-semibold hover:bg-primary-foreground/10 transition-colors">
              Contact Us
            </Link>
          </div>
        </motion.div>
      </div>
    </section>

    <Footer />
  </div>
);

export default ServicesPage;
