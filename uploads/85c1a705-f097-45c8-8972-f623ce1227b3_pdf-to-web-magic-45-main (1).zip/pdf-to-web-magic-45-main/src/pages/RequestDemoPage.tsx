import { useState } from "react";
import { motion } from "framer-motion";
import { ArrowRight, CheckCircle, Zap, Shield, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

const benefits = [
  { icon: Zap, title: "Quick Setup", desc: "Get started in minutes with our guided onboarding process." },
  { icon: Shield, title: "Secure Platform", desc: "Enterprise-grade security with AI-powered proctoring." },
  { icon: Users, title: "Dedicated Support", desc: "Personal account manager and 24/7 technical support." },
];

const RequestDemoPage = () => {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="min-h-screen">
      <Navbar />

      {/* Hero */}
      <section className="gradient-hero pt-32 pb-20 md:pt-40 md:pb-28">
        <div className="container">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl"
          >
            <span className="inline-block px-4 py-1.5 rounded-full bg-primary-foreground/15 text-primary-foreground text-sm font-medium mb-6 backdrop-blur-sm border border-primary-foreground/20">
              Request a Demo
            </span>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-primary-foreground leading-tight mb-4">
              See City Translink <span className="text-accent">In Action</span>
            </h1>
            <p className="text-lg md:text-xl text-primary-foreground/80 max-w-xl leading-relaxed">
              Schedule a personalized demo and discover how our assessment solutions can transform your organization.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Form + Benefits */}
      <section className="py-20 md:py-28">
        <div className="container">
          <div className="grid lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
            {/* Form */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              {submitted ? (
                <div className="bg-card rounded-2xl p-12 shadow-card border border-border flex flex-col items-center text-center">
                  <CheckCircle className="h-20 w-20 text-secondary mb-6" />
                  <h2 className="text-2xl font-bold text-foreground mb-3">Demo Request Submitted!</h2>
                  <p className="text-muted-foreground leading-relaxed max-w-sm">
                    Thank you for your interest. Our team will reach out within 24 hours to schedule your personalized demo.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="bg-card rounded-2xl p-8 shadow-card border border-border space-y-5">
                  <h2 className="text-2xl font-bold text-foreground mb-2">Schedule Your Demo</h2>
                  <p className="text-muted-foreground text-sm mb-4">Fill in the details below and we'll set up a personalized walkthrough.</p>
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-1.5">Full Name</label>
                      <Input placeholder="Your name" required />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-1.5">Company / Institution</label>
                      <Input placeholder="Organization name" required />
                    </div>
                  </div>
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-1.5">Email</label>
                      <Input type="email" placeholder="you@example.com" required />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-1.5">Phone</label>
                      <Input type="tel" placeholder="+91 XXXXX XXXXX" required />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-1.5">Service Interested In</label>
                    <select className="w-full rounded-md border border-input bg-background px-3 py-2.5 text-sm text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2">
                      <option value="">Select a service</option>
                      <option value="universities">For Universities</option>
                      <option value="schools">For Schools</option>
                      <option value="corporates">For Corporates</option>
                      <option value="sector-skill">For Sector Skill Council</option>
                      <option value="individuals">For Individuals</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-1.5">Requirements / Message</label>
                    <textarea rows={4} className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm text-foreground placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 resize-none" placeholder="Tell us about your needs..." />
                  </div>
                  <Button type="submit" className="w-full" size="lg">
                    Request Demo <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </form>
              )}
            </motion.div>

            {/* Benefits */}
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="flex flex-col justify-center"
            >
              <h2 className="text-3xl font-bold text-foreground mb-3">Why Request a Demo?</h2>
              <p className="text-muted-foreground leading-relaxed mb-8">
                See firsthand how our platform can streamline your assessment and recruitment processes with a no-obligation demonstration.
              </p>
              <div className="space-y-6">
                {benefits.map((b, i) => (
                  <motion.div
                    key={b.title}
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.1, duration: 0.4 }}
                    className="flex gap-4 bg-card rounded-xl p-5 shadow-card border border-border"
                  >
                    <div className="h-12 w-12 rounded-lg gradient-hero flex items-center justify-center shrink-0">
                      <b.icon className="h-6 w-6 text-primary-foreground" />
                    </div>
                    <div>
                      <h3 className="font-bold text-foreground mb-1">{b.title}</h3>
                      <p className="text-sm text-muted-foreground">{b.desc}</p>
                    </div>
                  </motion.div>
                ))}
              </div>

              <div className="mt-8 bg-card rounded-xl p-6 shadow-card border border-border">
                <h4 className="font-bold text-foreground mb-2">What happens next?</h4>
                <ol className="space-y-2 text-sm text-muted-foreground">
                  <li className="flex gap-2"><span className="font-bold text-primary">1.</span> Our team reviews your request</li>
                  <li className="flex gap-2"><span className="font-bold text-primary">2.</span> We schedule a convenient time for your demo</li>
                  <li className="flex gap-2"><span className="font-bold text-primary">3.</span> Get a personalized walkthrough of our platform</li>
                  <li className="flex gap-2"><span className="font-bold text-primary">4.</span> Receive a customized proposal for your needs</li>
                </ol>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default RequestDemoPage;
