import { motion } from "framer-motion";
import { CheckCircle, Eye, Target, Award, Globe, Users, TrendingUp, Calendar, Shield } from "lucide-react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import aboutImg from "@/assets/about-img.jpg";

const highlights = [
  "Government-recognized assessment organization",
  "Hybrid methodology with online & offline platforms",
  "Network of qualified TOA-accredited assessors",
  "Presence across 29 states & 7 union territories",
  "Partnerships with 100+ leading corporations",
  "300,000+ students assessed successfully",
];

const whyChoose = [
  { icon: Shield, title: "Expert & Professional", desc: "Seasoned professionals with TOA accreditation across various regions and sectors." },
  { icon: Globe, title: "Pan-India Coverage", desc: "Assessment infrastructure spanning 29 states and 7 union territories with localized centers." },
  { icon: TrendingUp, title: "Strategic Hiring", desc: "Efficient recruitment ensuring a strategic match between candidates and organizations." },
  { icon: Award, title: "Apprenticeship Support", desc: "Partnerships with 100+ corporations including Ultratech, Bajaj, Daikin, and more." },
];

const milestones = [
  { year: "2015", title: "Founded", desc: "City Translink established in Navi Mumbai with a vision to transform assessments." },
  { year: "2017", title: "PMKVY Certification", desc: "Became a certified assessment agency under Pradhan Mantri Kaushal Vikas Yojana." },
  { year: "2019", title: "100+ Corporate Partners", desc: "Expanded network to include leading Indian corporations for hiring solutions." },
  { year: "2021", title: "Online Platform Launch", desc: "Launched cutting-edge online examination platform supporting 100K+ concurrent users." },
  { year: "2023", title: "300K+ Assessments", desc: "Crossed the milestone of 300,000+ students assessed across India." },
  { year: "2024", title: "National Recognition", desc: "Recognized as a premier assessment entity in the skilling ecosystem." },
];

const AboutPage = () => (
  <div className="min-h-screen">
    <Navbar />

    {/* Hero */}
    <section className="gradient-hero pt-32 pb-20 md:pt-40 md:pb-28">
      <div className="container">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="max-w-3xl"
        >
          <span className="inline-block px-4 py-1.5 rounded-full bg-primary-foreground/15 text-primary-foreground text-sm font-medium mb-6 backdrop-blur-sm border border-primary-foreground/20">
            About Us
          </span>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-primary-foreground leading-tight mb-4">
            Bridging the Skill Gap <span className="text-accent">Across India</span>
          </h1>
          <p className="text-lg md:text-xl text-primary-foreground/80 max-w-xl leading-relaxed">
            A transparent assessment ecosystem employing a hybrid methodology, leveraging technology and qualified assessors to transform India's skill landscape.
          </p>
        </motion.div>
      </div>
    </section>

    {/* About Content */}
    <section className="py-20 md:py-28">
      <div className="container">
        <div className="grid md:grid-cols-2 gap-12 md:gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <img src={aboutImg} alt="Assessment center" loading="lazy" width={800} height={600} className="rounded-2xl shadow-card-hover w-full object-cover" />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <span className="text-secondary font-semibold text-sm uppercase tracking-widest">Who We Are</span>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mt-2 mb-6">
              India's Trusted Assessment Partner
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-6">
              City Translink offers a transparent assessment ecosystem that employs a hybrid methodology, leveraging a network of qualified assessors, localized test centers, practical evaluations, industry-validated question banks, and a versatile technology platform. Our mission is to narrow the Skill Gap within the nation.
            </p>
            <ul className="space-y-3">
              {highlights.map((h) => (
                <li key={h} className="flex items-start gap-3">
                  <CheckCircle className="h-5 w-5 text-secondary mt-0.5 shrink-0" />
                  <span className="text-foreground font-medium text-sm">{h}</span>
                </li>
              ))}
            </ul>
          </motion.div>
        </div>
      </div>
    </section>

    {/* Vision & Mission */}
    <section className="py-20 md:py-28 gradient-section">
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="text-secondary font-semibold text-sm uppercase tracking-widest">Our Purpose</span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mt-2 mb-4">Vision & Mission</h2>
        </div>
        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="bg-card rounded-2xl p-8 md:p-10 shadow-card border border-border"
          >
            <div className="h-14 w-14 rounded-xl gradient-hero flex items-center justify-center mb-5">
              <Eye className="h-7 w-7 text-primary-foreground" />
            </div>
            <h3 className="text-2xl font-bold text-foreground mb-4">Our Vision</h3>
            <p className="text-muted-foreground leading-relaxed">
              To establish City Translink as a premier assessment entity in the ever-evolving landscape of diverse skill assessments and corporate evaluations, becoming a fundamental contributor to the ongoing skilling revolution.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.15, duration: 0.5 }}
            className="bg-card rounded-2xl p-8 md:p-10 shadow-card border border-border"
          >
            <div className="h-14 w-14 rounded-xl bg-secondary flex items-center justify-center mb-5">
              <Target className="h-7 w-7 text-secondary-foreground" />
            </div>
            <h3 className="text-2xl font-bold text-foreground mb-4">Our Mission</h3>
            <p className="text-muted-foreground leading-relaxed">
              To enhance fairness and excellence within the Skill Development ecosystem by conducting research-based, valid, reliable, efficient, transparent, fair, and internationally benchmarked assessments.
            </p>
          </motion.div>
        </div>
      </div>
    </section>

    {/* Why Choose Us */}
    <section className="py-20 md:py-28">
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="text-secondary font-semibold text-sm uppercase tracking-widest">Why Choose Us</span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mt-2 mb-4">Why City Translink?</h2>
          <p className="text-muted-foreground">Research-backed assessments, certified assessors, and an efficient cloud platform.</p>
        </div>
        <div className="grid sm:grid-cols-2 gap-6 max-w-4xl mx-auto">
          {whyChoose.map((r, i) => (
            <motion.div
              key={r.title}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, duration: 0.5 }}
              className="flex gap-5 bg-card rounded-xl p-6 shadow-card border border-border"
            >
              <div className="h-12 w-12 rounded-lg gradient-hero flex items-center justify-center shrink-0">
                <r.icon className="h-6 w-6 text-primary-foreground" />
              </div>
              <div>
                <h3 className="text-base font-bold text-foreground mb-1">{r.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{r.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>

    {/* Timeline */}
    <section className="py-20 md:py-28 gradient-section">
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="text-secondary font-semibold text-sm uppercase tracking-widest">Our Journey</span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mt-2 mb-4">Milestones & Achievements</h2>
        </div>
        <div className="max-w-3xl mx-auto space-y-6">
          {milestones.map((m, i) => (
            <motion.div
              key={m.year}
              initial={{ opacity: 0, x: i % 2 === 0 ? -20 : 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08, duration: 0.5 }}
              className="flex gap-5 bg-card rounded-xl p-6 shadow-card border border-border"
            >
              <div className="h-14 w-14 rounded-xl gradient-hero flex items-center justify-center shrink-0">
                <span className="text-primary-foreground font-bold text-sm">{m.year}</span>
              </div>
              <div>
                <h3 className="text-base font-bold text-foreground mb-1">{m.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{m.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>

    <Footer />
  </div>
);

export default AboutPage;
