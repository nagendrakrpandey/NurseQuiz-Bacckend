import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import StatsSection from "@/components/StatsSection";
import ServicesSection from "@/components/ServicesSection";
import TestimonialsSection from "@/components/TestimonialsSection";
import PartnersSection from "@/components/PartnersSection";
import Footer from "@/components/Footer";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";

const Index = () => (
  <div className="min-h-screen">
    <Navbar />
    <HeroSection />
    <StatsSection />
    <ServicesSection />
    <TestimonialsSection />
    <PartnersSection />

    {/* CTA */}
    <section className="py-20 md:py-28 gradient-hero">
      <div className="container text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
        >
          <h2 className="text-3xl md:text-4xl font-bold text-primary-foreground mb-4">
            Ready to Transform Your Assessment Process?
          </h2>
          <p className="text-primary-foreground/70 max-w-lg mx-auto mb-8">
            Join 300,000+ students and 100+ organizations who trust City Translink.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/request-demo" className="inline-flex items-center justify-center rounded-md bg-secondary text-secondary-foreground px-8 py-3 text-base font-semibold hover:bg-secondary/90 transition-colors">
              Request Demo <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
            <Link to="/contact" className="inline-flex items-center justify-center rounded-md border border-primary-foreground/30 text-primary-foreground px-8 py-3 text-base font-semibold hover:bg-primary-foreground/10 transition-colors">
              Contact Us
            </Link>
          </div>
        </motion.div>
      </div>
    </section>

    <Footer />
  </div>
);

export default Index;
