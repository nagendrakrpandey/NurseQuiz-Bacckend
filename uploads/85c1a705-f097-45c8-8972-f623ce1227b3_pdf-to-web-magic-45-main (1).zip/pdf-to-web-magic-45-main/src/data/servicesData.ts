import { GraduationCap, School, Building2, ShieldCheck, User } from "lucide-react";

export interface ServicePageData {
  slug: string;
  icon: typeof GraduationCap;
  title: string;
  subtitle: string;
  heroDesc: string;
  description: string;
  features: { title: string; desc: string }[];
  benefits: string[];
}

export const servicesData: ServicePageData[] = [
  {
    slug: "universities",
    icon: GraduationCap,
    title: "For Universities & Colleges",
    subtitle: "Comprehensive Assessment Solutions for Higher Education",
    heroDesc: "Empower your institution with cutting-edge online examination systems, employability evaluations, and entrance exam automation.",
    description: "City Translink provides universities and colleges with a robust assessment infrastructure that covers entrance examinations, semester assessments, and employability evaluations. Our platform supports large-scale online exams with AI-powered proctoring, automated grading, and detailed analytics to help institutions make data-driven decisions.",
    features: [
      { title: "Online Examination Platform", desc: "Scalable web-based exams with AI proctoring supporting 100K+ concurrent users." },
      { title: "Employability Assessment", desc: "Evaluate graduate readiness with industry-aligned competency frameworks." },
      { title: "Entrance Exam Automation", desc: "End-to-end exam management from registration to result declaration." },
      { title: "Question Bank Management", desc: "Industry-validated question banks with difficulty-level categorization." },
      { title: "Analytics Dashboard", desc: "Comprehensive reports on student performance, trends, and institutional benchmarks." },
      { title: "Placement Support", desc: "Connect graduates with corporate partners through integrated placement drives." },
    ],
    benefits: [
      "Reduce examination costs by up to 60%",
      "Eliminate paper-based logistical challenges",
      "Real-time results and analytics",
      "Secure and tamper-proof assessments",
      "Compliance with UGC and AICTE guidelines",
      "24/7 technical support",
    ],
  },
  {
    slug: "schools",
    icon: School,
    title: "For Schools",
    subtitle: "Career Guidance & Safety Assessments for K-12",
    heroDesc: "Help students discover their potential with psychometric assessments and ensure campus safety with staff evaluation programs.",
    description: "Our school assessment solutions focus on holistic student development through career guidance, psychometric testing, and aptitude evaluation. We also provide comprehensive safety assessments for school staff to create a secure learning environment.",
    features: [
      { title: "Career Guidance Program", desc: "Psychometric assessments helping students choose the right career path from Class 8 onwards." },
      { title: "Aptitude & Skill Testing", desc: "Identify student strengths across logical, verbal, numerical, and creative domains." },
      { title: "Staff Safety Evaluation", desc: "Comprehensive background and psychometric screening for all school staff." },
      { title: "Parent-Teacher Insights", desc: "Detailed reports bridging the gap between academic performance and career potential." },
      { title: "Olympiad & Competition Prep", desc: "Practice assessments for national and international academic competitions." },
      { title: "Digital Literacy Assessment", desc: "Evaluate and enhance students' digital skills for the modern world." },
    ],
    benefits: [
      "Scientific career guidance from an early age",
      "Enhanced student engagement and motivation",
      "Safe and secure campus environment",
      "Data-driven parent-teacher meetings",
      "Affordable and scalable solutions",
      "Aligned with NEP 2020 objectives",
    ],
  },
  {
    slug: "corporates",
    icon: Building2,
    title: "For Corporates",
    subtitle: "End-to-End Hiring & Workforce Assessment",
    heroDesc: "Streamline your recruitment pipeline with AI-powered screening, competency assessments, and strategic hiring solutions.",
    description: "City Translink offers corporates a complete hiring and assessment suite — from initial candidate screening to competency-based evaluations for existing employees. Our platform helps organizations find the right talent faster while reducing hiring costs and improving retention rates.",
    features: [
      { title: "Campus Recruitment", desc: "Conduct large-scale campus drives with automated screening and shortlisting." },
      { title: "Aptitude & Technical Tests", desc: "Customizable test batteries covering aptitude, domain knowledge, and coding skills." },
      { title: "Competency Assessment", desc: "360-degree evaluation frameworks for existing employees aligned to organizational goals." },
      { title: "Video Interview Platform", desc: "AI-assisted video interviews with sentiment analysis and skill scoring." },
      { title: "Apprenticeship Management", desc: "End-to-end apprenticeship program management in partnership with NAPS/NATS." },
      { title: "HR Analytics", desc: "Workforce analytics dashboards for informed talent management decisions." },
    ],
    benefits: [
      "Reduce time-to-hire by 40%",
      "Data-driven hiring decisions",
      "Improved employee retention rates",
      "Compliance with labor regulations",
      "Partnerships with 100+ corporations",
      "Customizable assessment frameworks",
    ],
  },
  {
    slug: "sector-skill",
    icon: ShieldCheck,
    title: "For Sector Skill Council",
    subtitle: "PMKVY & QP-Based Assessment Services",
    heroDesc: "Delivering certified, multi-language assessments with 1000+ accredited assessors across all states and union territories.",
    description: "As a certified assessment agency under PMKVY, City Translink conducts QP-based assessments with a network of 1000+ TOA-certified assessors. We provide content development, multi-language translation, and comprehensive assessment services across 29 states and 7 union territories.",
    features: [
      { title: "PMKVY Assessments", desc: "Certified assessment delivery for Pradhan Mantri Kaushal Vikas Yojana across India." },
      { title: "QP-Based Content", desc: "Development of assessment content aligned with National Occupational Standards." },
      { title: "Multi-Language Support", desc: "Assessments available in 15+ Indian languages for maximum accessibility." },
      { title: "Assessor Network", desc: "1000+ TOA-accredited assessors deployed across all states and union territories." },
      { title: "RPL Assessments", desc: "Recognition of Prior Learning assessments for informal sector workers." },
      { title: "Real-Time Monitoring", desc: "Live dashboard for SSC partners to monitor assessment progress and results." },
    ],
    benefits: [
      "Pan-India coverage across 29 states",
      "Government-recognized assessment agency",
      "Transparent and tamper-proof process",
      "Quick turnaround on results",
      "Compliance with NSDC guidelines",
      "Dedicated SSC relationship managers",
    ],
  },
  {
    slug: "individuals",
    icon: User,
    title: "For Individuals",
    subtitle: "Certifications & Career Advancement",
    heroDesc: "Boost your career with industry-recognized certifications across multiple sectors and skill domains.",
    description: "City Translink empowers individuals with a range of certification options including university certifications, industry certifications, sector skill certifications, and CTAT certifications. Our assessments are designed to validate your skills and open doors to new career opportunities.",
    features: [
      { title: "University Certifications", desc: "Accredited certifications from partnered universities for academic advancement." },
      { title: "Industry Certifications", desc: "Domain-specific certifications recognized by leading corporations." },
      { title: "Sector Skill Certifications", desc: "NSQF-aligned certifications for skilled workers across various sectors." },
      { title: "CTAT Certifications", desc: "Certified Test Administration & Assessment certifications for aspiring assessors." },
      { title: "Skill Gap Analysis", desc: "Personalized assessment to identify skill gaps and recommend learning paths." },
      { title: "Digital Credentials", desc: "Blockchain-verified digital certificates shareable on LinkedIn and job portals." },
    ],
    benefits: [
      "Industry-recognized credentials",
      "Flexible online assessment options",
      "Affordable certification programs",
      "Career guidance and counseling",
      "Access to job opportunities",
      "Lifelong learning pathways",
    ],
  },
];
