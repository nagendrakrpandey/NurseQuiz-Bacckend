import { motion } from "framer-motion";

const partners = [
  "Ultratech", "Bajaj Auto", "Daikin", "Godrej", "L&T",
  "Mahindra", "Tata Motors", "Wipro", "HCL", "Infosys",
];

const PartnersSection = () => (
  <section className="py-16 md:py-20 gradient-section">
    <div className="container">
      <div className="text-center mb-10">
        <span className="text-secondary font-semibold text-sm uppercase tracking-widest">Our Partners</span>
        <h2 className="text-2xl md:text-3xl font-bold text-foreground mt-2">
          Trusted by 100+ Leading Organizations
        </h2>
      </div>

      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="flex flex-wrap justify-center items-center gap-6 md:gap-10 max-w-5xl mx-auto"
      >
        {partners.map((p, i) => (
          <motion.div
            key={p}
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.05, duration: 0.4 }}
            className="bg-card rounded-xl px-8 py-4 shadow-card border border-border hover:shadow-card-hover transition-shadow duration-300"
          >
            <span className="font-heading font-bold text-muted-foreground text-sm md:text-base">{p}</span>
          </motion.div>
        ))}
      </motion.div>
    </div>
  </section>
);

export default PartnersSection;
