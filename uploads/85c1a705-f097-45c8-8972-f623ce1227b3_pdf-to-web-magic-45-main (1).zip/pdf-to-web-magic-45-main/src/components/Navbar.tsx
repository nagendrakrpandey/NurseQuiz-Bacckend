import { useState, useRef, useEffect } from "react";
import { Menu, X, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link, useLocation } from "react-router-dom";

const serviceLinks = [
  { label: "For Universities", href: "/services/universities" },
  { label: "For Schools", href: "/services/schools" },
  { label: "For Corporates", href: "/services/corporates" },
  { label: "For Sector Skill Council", href: "/services/sector-skill" },
  { label: "For Individuals", href: "/services/individuals" },
];

const navLinks = [
  { label: "Home", href: "/" },
  { label: "About", href: "/about" },
  { label: "Contact", href: "/contact" },
];

const Navbar = () => {
  const [open, setOpen] = useState(false);
  const [servicesOpen, setServicesOpen] = useState(false);
  const [mobileServicesOpen, setMobileServicesOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const location = useLocation();

  useEffect(() => {
    setOpen(false);
    setServicesOpen(false);
    setMobileServicesOpen(false);
  }, [location]);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setServicesOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 10);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const isActive = (href: string) => location.pathname === href;
  const isServiceActive = location.pathname.startsWith("/services");

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 bg-background/95 backdrop-blur-md border-b transition-shadow duration-300 ${scrolled ? "shadow-md border-border" : "border-transparent"}`}>
      <div className="container flex items-center justify-between h-16 md:h-20">
        <Link to="/" className="font-heading text-xl md:text-2xl font-bold tracking-tight">
          <span className="text-primary">City</span><span className="text-secondary">Translink</span>
        </Link>

        {/* Desktop */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              to={link.href}
              className={`text-sm font-medium transition-colors ${isActive(link.href) ? "text-primary font-semibold" : "text-muted-foreground hover:text-primary"}`}
            >
              {link.label}
            </Link>
          ))}

          {/* Services Dropdown */}
          <div className="relative" ref={dropdownRef}>
            <button
              onClick={() => setServicesOpen(!servicesOpen)}
              className={`flex items-center gap-1 text-sm font-medium transition-colors ${isServiceActive ? "text-primary font-semibold" : "text-muted-foreground hover:text-primary"}`}
            >
              Services
              <ChevronDown className={`h-4 w-4 transition-transform duration-200 ${servicesOpen ? "rotate-180" : ""}`} />
            </button>
            {servicesOpen && (
              <div className="absolute top-full left-1/2 -translate-x-1/2 mt-3 w-64 bg-background rounded-xl shadow-lg border border-border py-2 animate-fade-in">
                <Link
                  to="/services"
                  className="block px-5 py-2.5 text-sm font-semibold text-foreground hover:text-primary hover:bg-muted transition-colors border-b border-border"
                >
                  All Services
                </Link>
                {serviceLinks.map((s) => (
                  <Link
                    key={s.href}
                    to={s.href}
                    className={`block px-5 py-2.5 text-sm transition-colors ${isActive(s.href) ? "text-primary font-semibold bg-muted" : "text-muted-foreground hover:text-primary hover:bg-muted"}`}
                  >
                    {s.label}
                  </Link>
                ))}
              </div>
            )}
          </div>

          <Button asChild>
            <Link to="/request-demo">Request Demo</Link>
          </Button>
        </div>

        {/* Mobile toggle */}
        <button className="md:hidden text-foreground" onClick={() => setOpen(!open)}>
          {open ? <X size={24} /> : <Menu size={24} />}
        </button>
      </div>

      {/* Mobile menu */}
      {open && (
        <div className="md:hidden bg-background border-b border-border pb-4 animate-fade-in">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              to={link.href}
              className={`block px-6 py-3 text-sm font-medium ${isActive(link.href) ? "text-primary font-semibold" : "text-muted-foreground hover:text-primary"}`}
            >
              {link.label}
            </Link>
          ))}

          <button
            onClick={() => setMobileServicesOpen(!mobileServicesOpen)}
            className={`flex items-center justify-between w-full px-6 py-3 text-sm font-medium ${isServiceActive ? "text-primary font-semibold" : "text-muted-foreground hover:text-primary"}`}
          >
            Services
            <ChevronDown className={`h-4 w-4 transition-transform duration-200 ${mobileServicesOpen ? "rotate-180" : ""}`} />
          </button>
          {mobileServicesOpen && (
            <div className="bg-muted/50">
              <Link to="/services" className="block px-10 py-2.5 text-sm font-semibold text-foreground hover:text-primary">
                All Services
              </Link>
              {serviceLinks.map((s) => (
                <Link
                  key={s.href}
                  to={s.href}
                  className={`block px-10 py-2.5 text-sm ${isActive(s.href) ? "text-primary font-semibold" : "text-muted-foreground hover:text-primary"}`}
                >
                  {s.label}
                </Link>
              ))}
            </div>
          )}

          <div className="px-6 pt-2">
            <Button asChild className="w-full">
              <Link to="/request-demo">Request Demo</Link>
            </Button>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
