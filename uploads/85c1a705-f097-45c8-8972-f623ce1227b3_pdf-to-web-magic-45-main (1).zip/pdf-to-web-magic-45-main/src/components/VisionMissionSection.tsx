import { motion } from "framer-motion";
import { Eye, Target } from "lucide-react";

const VisionMissionSection = () => (
  <section className="py-20 md:py-28">
    <div className="container">
      <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="bg-card rounded-2xl p-8 md:p-10 shadow-card border border-border"
        >
          <div className="h-14 w-14 rounded-xl gradient-hero flex items-center justify-center mb-5">
            <Eye className="h-7 w-7 text-primary-foreground" />
          </div>
          <h3 className="text-2xl font-bold text-foreground mb-4">Our Vision</h3>
          <p className="text-muted-foreground leading-relaxed">
            To establish City Translink as a premier assessment entity in the ever-evolving landscape of diverse skill assessments and corporate evaluations, becoming a fundamental contributor to the ongoing skilling revolution.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.15, duration: 0.5 }}
          className="bg-card rounded-2xl p-8 md:p-10 shadow-card border border-border"
        >
          <div className="h-14 w-14 rounded-xl bg-secondary flex items-center justify-center mb-5">
            <Target className="h-7 w-7 text-secondary-foreground" />
          </div>
          <h3 className="text-2xl font-bold text-foreground mb-4">Our Mission</h3>
          <p className="text-muted-foreground leading-relaxed">
            To enhance fairness and excellence within the Skill Development ecosystem by conducting research-based, valid, reliable, efficient, transparent, fair, and internationally benchmarked assessments.
          </p>
        </motion.div>
      </div>
    </div>
  </section>
);

export default VisionMissionSection;
