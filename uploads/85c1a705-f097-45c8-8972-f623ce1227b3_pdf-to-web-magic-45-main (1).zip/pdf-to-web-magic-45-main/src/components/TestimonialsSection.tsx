import { motion } from "framer-motion";
import { Star, Quote } from "lucide-react";

const testimonials = [
  {
    name: "Dr. Rajesh Sharma",
    role: "Dean, Mumbai University",
    text: "City Translink has revolutionized our examination process. Their online assessment platform is reliable, scalable, and incredibly efficient for our 50,000+ students.",
    rating: 5,
  },
  {
    name: "Priya Mehta",
    role: "HR Director, Bajaj Auto",
    text: "The recruitment solutions provided by City Translink helped us streamline our campus hiring. Their competency-based assessments ensure we find the right talent every time.",
    rating: 5,
  },
  {
    name: "Amit Patel",
    role: "CEO, SkillIndia Partner",
    text: "As a Sector Skill Council partner, we've found City Translink's PMKVY assessment services to be thorough, transparent, and consistently high in quality. Their certified assessors are truly outstanding.",
    rating: 5,
  },
];

const TestimonialsSection = () => (
  <section className="py-20 md:py-28">
    <div className="container">
      <div className="text-center max-w-2xl mx-auto mb-14">
        <span className="text-secondary font-semibold text-sm uppercase tracking-widest">Testimonials</span>
        <h2 className="text-3xl md:text-4xl font-bold text-foreground mt-2 mb-4">
          What Our Clients Say
        </h2>
        <p className="text-muted-foreground">
          Trusted by leading institutions, corporations, and government bodies across India.
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-6 max-w-6xl mx-auto">
        {testimonials.map((t, i) => (
          <motion.div
            key={t.name}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1, duration: 0.5 }}
            className="bg-card rounded-2xl p-8 shadow-card border border-border relative"
          >
            <Quote className="h-8 w-8 text-primary/15 absolute top-6 right-6" />
            <div className="flex gap-1 mb-4">
              {Array.from({ length: t.rating }).map((_, idx) => (
                <Star key={idx} className="h-4 w-4 fill-accent text-accent" />
              ))}
            </div>
            <p className="text-muted-foreground text-sm leading-relaxed mb-6">"{t.text}"</p>
            <div>
              <p className="font-bold text-foreground text-sm">{t.name}</p>
              <p className="text-xs text-muted-foreground">{t.role}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default TestimonialsSection;
