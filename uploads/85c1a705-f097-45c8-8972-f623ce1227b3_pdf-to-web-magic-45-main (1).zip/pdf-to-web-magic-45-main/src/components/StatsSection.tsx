import { motion } from "framer-motion";
import { Users, BookOpen, Calendar, Award } from "lucide-react";

const stats = [
  { icon: Users, value: "300K+", label: "Students Assessed" },
  { icon: BookOpen, value: "64+", label: "Courses Offered" },
  { icon: Calendar, value: "42+", label: "Events Conducted" },
  { icon: Award, value: "15+", label: "Expert Trainers" },
];

const StatsSection = () => (
  <section className="relative -mt-16 z-20">
    <div className="container">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
        {stats.map((s, i) => (
          <motion.div
            key={s.label}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1, duration: 0.5 }}
            className="bg-card rounded-xl p-6 md:p-8 shadow-card text-center"
          >
            <s.icon className="h-8 w-8 text-secondary mx-auto mb-3" />
            <div className="text-3xl md:text-4xl font-extrabold text-primary mb-1">{s.value}</div>
            <div className="text-sm text-muted-foreground font-medium">{s.label}</div>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default StatsSection;
