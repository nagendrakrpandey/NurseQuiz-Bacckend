import { motion } from "framer-motion";
import { CheckCircle } from "lucide-react";
import aboutImg from "@/assets/about-img.jpg";

const highlights = [
  "Government-recognized assessment organization",
  "Hybrid methodology with online & offline platforms",
  "Network of qualified TOA-accredited assessors",
  "Presence across 29 states & 7 union territories",
];

const AboutSection = () => (
  <section id="about" className="py-20 md:py-28 gradient-section">
    <div className="container">
      <div className="grid md:grid-cols-2 gap-12 md:gap-16 items-center">
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <img src={aboutImg} alt="Assessment center" loading="lazy" width={800} height={600} className="rounded-2xl shadow-card-hover w-full object-cover" />
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <span className="text-secondary font-semibold text-sm uppercase tracking-widest">Who We Are</span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mt-2 mb-6">
            Bridging the Skill Gap Across India
          </h2>
          <p className="text-muted-foreground leading-relaxed mb-6">
            City Translink offers a transparent assessment ecosystem that employs a hybrid methodology, leveraging a network of qualified assessors, localized test centers, practical evaluations, industry-validated question banks, and a versatile technology platform. Our mission is to narrow the Skill Gap within the nation.
          </p>
          <ul className="space-y-3">
            {highlights.map((h) => (
              <li key={h} className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-secondary mt-0.5 shrink-0" />
                <span className="text-foreground font-medium text-sm">{h}</span>
              </li>
            ))}
          </ul>
        </motion.div>
      </div>
    </div>
  </section>
);

export default AboutSection;
