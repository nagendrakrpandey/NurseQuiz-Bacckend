import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { servicesData } from "@/data/servicesData";

const ServicesSection = () => (
  <section id="services" className="py-20 md:py-28">
    <div className="container">
      <div className="text-center max-w-2xl mx-auto mb-14">
        <span className="text-secondary font-semibold text-sm uppercase tracking-widest">Our Services</span>
        <h2 className="text-3xl md:text-4xl font-bold text-foreground mt-2 mb-4">
          Comprehensive Assessment Solutions
        </h2>
        <p className="text-muted-foreground">
          Tailored evaluation services for every sector of the education and employment ecosystem.
        </p>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {servicesData.map((s, i) => (
          <motion.div
            key={s.title}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1, duration: 0.5 }}
          >
            <Link
              to={`/services/${s.slug}`}
              className="group block bg-card rounded-xl p-8 shadow-card hover:shadow-card-hover transition-all duration-300 border border-border h-full"
            >
              <div className="h-14 w-14 rounded-xl gradient-hero flex items-center justify-center mb-5">
                <s.icon className="h-7 w-7 text-primary-foreground" />
              </div>
              <h3 className="text-lg font-bold text-foreground mb-3">{s.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed mb-4">{s.heroDesc}</p>
              <span className="inline-flex items-center text-sm font-semibold text-primary group-hover:gap-2 transition-all">
                Learn More <ArrowRight className="ml-1 h-4 w-4" />
              </span>
            </Link>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default ServicesSection;
