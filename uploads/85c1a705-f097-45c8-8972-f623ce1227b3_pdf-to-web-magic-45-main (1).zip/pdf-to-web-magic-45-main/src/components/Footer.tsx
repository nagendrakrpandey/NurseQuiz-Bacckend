import { Link } from "react-router-dom";
import { Facebook, Twitter, Linkedin, Instagram } from "lucide-react";

const serviceLinks = [
  { label: "For Universities", href: "/services/universities" },
  { label: "For Schools", href: "/services/schools" },
  { label: "For Corporates", href: "/services/corporates" },
  { label: "For Sector Skill Council", href: "/services/sector-skill" },
  { label: "For Individuals", href: "/services/individuals" },
];

const quickLinks = [
  { label: "Home", href: "/" },
  { label: "About Us", href: "/about" },
  { label: "Services", href: "/services" },
  { label: "Contact", href: "/contact" },
  { label: "Request Demo", href: "/request-demo" },
];

const Footer = () => (
  <footer className="gradient-hero py-12">
    <div className="container">
      <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-8 mb-10">
        <div>
          <Link to="/" className="font-heading text-xl font-bold text-primary-foreground mb-3 block">
            City<span className="text-accent">Translink</span>
          </Link>
          <p className="text-primary-foreground/70 text-sm leading-relaxed mb-4">
            A transparent assessment ecosystem leveraging technology and expertise across India.
          </p>
          <div className="flex gap-3">
            {[Facebook, Twitter, Linkedin, Instagram].map((Icon, i) => (
              <a key={i} href="#" className="h-9 w-9 rounded-lg bg-primary-foreground/10 flex items-center justify-center hover:bg-primary-foreground/20 transition-colors">
                <Icon className="h-4 w-4 text-primary-foreground" />
              </a>
            ))}
          </div>
        </div>

        <div>
          <h4 className="font-semibold text-primary-foreground mb-3 text-sm">Quick Links</h4>
          <ul className="space-y-2 text-sm text-primary-foreground/70">
            {quickLinks.map((l) => (
              <li key={l.href}>
                <Link to={l.href} className="hover:text-primary-foreground transition-colors">{l.label}</Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="font-semibold text-primary-foreground mb-3 text-sm">Our Services</h4>
          <ul className="space-y-2 text-sm text-primary-foreground/70">
            {serviceLinks.map((l) => (
              <li key={l.href}>
                <Link to={l.href} className="hover:text-primary-foreground transition-colors">{l.label}</Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="font-semibold text-primary-foreground mb-3 text-sm">Contact</h4>
          <ul className="space-y-2 text-sm text-primary-foreground/70">
            <li>405, Vashi Infotech Park, Sector 30A, Vashi, Navi Mumbai - 400703</li>
            <li>+91 9324121410</li>
            <li>22-40220707</li>
            <li>info@citytranslink.com</li>
          </ul>
        </div>
      </div>

      <div className="border-t border-primary-foreground/15 pt-6 flex flex-col sm:flex-row justify-between items-center gap-3">
        <p className="text-primary-foreground/60 text-xs">© {new Date().getFullYear()} City Translink. All Rights Reserved</p>
        <div className="flex gap-4 text-xs text-primary-foreground/60">
          <a href="#" className="hover:text-primary-foreground transition-colors">Terms of Service</a>
          <a href="#" className="hover:text-primary-foreground transition-colors">Privacy Policy</a>
        </div>
      </div>
    </div>
  </footer>
);

export default Footer;
