import { motion } from "framer-motion";
import { UserCheck, Monitor, Briefcase, BookOpenCheck } from "lucide-react";

const reasons = [
  {
    icon: UserCheck,
    title: "Expert & Professional",
    desc: "Seasoned professionals with expert-level proficiency and TOA accreditation across various regions and sectors.",
  },
  {
    icon: Monitor,
    title: "Online Exam Platform",
    desc: "Web-based assessments accessible remotely with research-backed methodology and advanced cloud platform.",
  },
  {
    icon: Briefcase,
    title: "Strategic Hiring",
    desc: "Efficient recruitment ensuring a strategic match between candidates and organizational needs.",
  },
  {
    icon: BookOpenCheck,
    title: "Apprenticeship Support",
    desc: "Partnerships with 100+ leading corporations including Ultratech, Bajaj, Daikin, and more for apprenticeship and hiring.",
  },
];

const WhyChooseSection = () => (
  <section id="why-us" className="py-20 md:py-28 gradient-section">
    <div className="container">
      <div className="text-center max-w-2xl mx-auto mb-14">
        <span className="text-secondary font-semibold text-sm uppercase tracking-widest">Why Choose Us</span>
        <h2 className="text-3xl md:text-4xl font-bold text-foreground mt-2 mb-4">
          Why Choose City Translink?
        </h2>
        <p className="text-muted-foreground">
          Research-backed assessments, certified assessors, and an efficient cloud platform delivering transformative outcomes.
        </p>
      </div>

      <div className="grid sm:grid-cols-2 gap-6 max-w-4xl mx-auto">
        {reasons.map((r, i) => (
          <motion.div
            key={r.title}
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1, duration: 0.5 }}
            className="flex gap-5 bg-card rounded-xl p-6 shadow-card border border-border"
          >
            <div className="h-12 w-12 rounded-lg gradient-hero flex items-center justify-center shrink-0">
              <r.icon className="h-6 w-6 text-primary-foreground" />
            </div>
            <div>
              <h3 className="text-base font-bold text-foreground mb-1">{r.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{r.desc}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

export default WhyChooseSection;
